# First of all, we thank you for your purchase and willingness of using Tailone in your projects! #

Tailone is Tailwind One Page Template, this template is easy to development.

### How to start with Tailone? ###

It's simple and easy, just open `docs/index.html` and Tailone documentation will guide you with detailed step by step information.

### License ###

Tailone is licensed under Tailnet License and you can find more detailed information about it in https://tailwindtemplate.net/license/

### Free updates and support ###

After purchasing a Tailone Template copy, you get the right for a lifetime entitlement to download updates for FREE! Need help? For any questions or concerns, reach us out at support@tailwindtemplate.net

### Have idea for next update? ###

If you have any idea for next update or find bugs in template, We is very happy if you give idea or suggestion to support@tailwindtemplate.net